package lumien.bloodmoon.server;

import lumien.bloodmoon.config.BloodmoonConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Port of the original BloodmoonSpawner.findChunksForSpawning.
 * Spawns monsters during a blood moon with:
 * - spawn limit multiplied by SPAWN_LIMIT_MULT (default 4)
 * - minimum player distance SPAWN_RANGE blocks (default 2, vanilla is 24)
 * - world spawn distance SPAWN_DISTANCE blocks (default 24)
 * - whitelist/blacklist filtering by entity name
 * Mobs spawned here are marked with the "bloodmoonSpawned" entity tag.
 */
public final class BloodmoonSpawner {
    /** Entity tag applied to all mobs spawned by the bloodmoon spawner. */
    public static final String SPAWN_TAG = "bloodmoonSpawned";

    /** Vanilla magic number: 17^2 */
    private static final int MOB_COUNT_DIV = 289;
    private static final int SPAWN_RADIUS_CHUNKS = 8;

    /** Dedicated random source (Level.random is protected in 26.2). */
    private static final RandomSource RANDOM = RandomSource.create();

    private BloodmoonSpawner() {
    }

    /**
     * Runs one spawn cycle (called multiple times per tick depending on
     * SPAWN_SPEED). Returns the number of mobs spawned.
     */
    public static int spawnCycle(ServerLevel level, boolean spawnHostile) {
        if (!spawnHostile) {
            return 0;
        }

        // Collect eligible chunks around every player (8 chunk radius).
        Set<ChunkPos> eligibleChunks = new HashSet<>();
        int chunkCount = 0;
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) {
                continue;
            }
            int playerChunkX = Mth.floor(player.getX() / 16.0);
            int playerChunkZ = Mth.floor(player.getZ() / 16.0);
            for (int dx = -SPAWN_RADIUS_CHUNKS; dx <= SPAWN_RADIUS_CHUNKS; dx++) {
                for (int dz = -SPAWN_RADIUS_CHUNKS; dz <= SPAWN_RADIUS_CHUNKS; dz++) {
                    boolean edge = dx == -SPAWN_RADIUS_CHUNKS || dx == SPAWN_RADIUS_CHUNKS
                            || dz == -SPAWN_RADIUS_CHUNKS || dz == SPAWN_RADIUS_CHUNKS;
                    ChunkPos chunkPos = new ChunkPos(dx + playerChunkX, dz + playerChunkZ);
                    if (eligibleChunks.add(chunkPos)) {
                        chunkCount++;
                        if (!edge && level.getWorldBorder().isWithinBounds(chunkPos)) {
                            LevelChunk chunk = level.getChunkSource().getChunkNow(chunkPos.x(), chunkPos.z());
                            if (chunk != null && level.canSpawnEntitiesInChunk(chunkPos)) {
                                // chunk stays in the set; edge chunks were counted but will be skipped below
                            } else {
                                eligibleChunks.remove(chunkPos);
                            }
                        } else if (edge) {
                            eligibleChunks.remove(chunkPos);
                        }
                    }
                }
            }
        }

        if (eligibleChunks.isEmpty()) {
            return 0;
        }

        // Check the (multiplied) monster cap using the vanilla spawn state counter.
        NaturalSpawner.SpawnState spawnState = level.getChunkSource().getLastSpawnState();
        int currentMonsters = 0;
        if (spawnState != null) {
            currentMonsters = spawnState.getMobCategoryCounts().getInt(MobCategory.MONSTER);
        }
        int spawnLimit = MobCategory.MONSTER.getMaxInstancesPerChunk() * chunkCount / MOB_COUNT_DIV
                * Math.max(1, BloodmoonConfig.SPAWNING.SPAWN_LIMIT_MULT);
        if (currentMonsters >= spawnLimit) {
            return 0;
        }

        List<ChunkPos> shuffled = new ArrayList<>(eligibleChunks);
        Collections.shuffle(shuffled);

        int spawnedTotal = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (ChunkPos chunkPos : shuffled) {
            LevelChunk chunk = level.getChunkSource().getChunkNow(chunkPos.x(), chunkPos.z());
            if (chunk == null) {
                continue;
            }

            // Random position within the chunk (like vanilla getRandomPosWithin)
            int startX = chunkPos.getMinBlockX() + RANDOM.nextInt(16);
            int startZ = chunkPos.getMinBlockZ() + RANDOM.nextInt(16);
            int topY = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, startX, startZ) + 1;
            int startY = Mth.randomBetweenInclusive(RANDOM, level.getMinY(), topY);
            if (startY < level.getMinY() + 1) {
                continue;
            }
            if (chunk.getBlockState(pos.set(startX, startY, startZ)).isRedstoneConductor(chunk, pos)) {
                continue;
            }

            // Group spawn loop (like vanilla spawnCategoryForPosition)
            int clusterSize = 0;
            MobSpawnSettings.SpawnerData spawnData = null;
            SpawnGroupData groupData = null;

            for (int group = 0; group < 3; group++) {
                int x = startX;
                int z = startZ;
                int max = Mth.ceil(RANDOM.nextFloat() * 4.0F);
                int groupSize = 0;

                for (int attempt = 0; attempt < max; attempt++) {
                    x += RANDOM.nextInt(6) - RANDOM.nextInt(6);
                    z += RANDOM.nextInt(6) - RANDOM.nextInt(6);
                    pos.set(x, startY, z);
                    double wx = x + 0.5;
                    double wz = z + 0.5;

                    // Bloodmoon spawn rules: only SPAWN_RANGE blocks away from players
                    float spawnRange = Math.max(0, BloodmoonConfig.SPAWNING.SPAWN_RANGE);
                    if (level.getNearestPlayer(wx, startY, wz, spawnRange, false) != null) {
                        continue;
                    }

                    // Keep distance from the world spawn point
                    int spawnDistance = Math.max(0, BloodmoonConfig.SPAWNING.SPAWN_DISTANCE);
                    if (level.getRespawnData().pos()
                            .closerToCenterThan(new Vec3(wx, startY, wz), spawnDistance)) {
                        continue;
                    }

                    if (spawnData == null) {
                        Optional<MobSpawnSettings.SpawnerData> data = pickSpawnData(level, pos);
                        if (data.isEmpty()) {
                            break;
                        }
                        spawnData = data.get();
                        max = spawnData.minCount() + RANDOM.nextInt(1 + spawnData.maxCount() - spawnData.minCount());
                    }

                    EntityType<?> type = spawnData.type();
                    if (!SpawnPlacements.isSpawnPositionOk(type, level, pos)) {
                        continue;
                    }
                    if (!SpawnPlacements.checkSpawnRules(type, level, EntitySpawnReason.NATURAL, pos, RANDOM)) {
                        continue;
                    }
                    if (!level.noCollision(type.getSpawnAABB(wx, startY, wz))) {
                        continue;
                    }

                    Mob mob;
                    try {
                        if (!(type.create(level, EntitySpawnReason.NATURAL) instanceof Mob m)) {
                            return spawnedTotal;
                        }
                        mob = m;
                    } catch (Exception e) {
                        return spawnedTotal;
                    }

                    mob.snapTo(wx, startY, wz, RANDOM.nextFloat() * 360.0F, 0.0F);
                    if (mob.checkSpawnObstruction(level)) {
                        groupData = mob.finalizeSpawn(level, level.getCurrentDifficultyAt(mob.blockPosition()),
                                EntitySpawnReason.NATURAL, groupData);
                        clusterSize++;
                        groupSize++;
                        mob.addTag(SPAWN_TAG);
                        level.addFreshEntityWithPassengers(mob);
                        spawnedTotal++;

                        if (clusterSize >= mob.getMaxSpawnClusterSize()) {
                            break;
                        }
                        if (mob.isMaxGroupSizeReached(groupSize)) {
                            break;
                        }
                    }
                }
                if (clusterSize >= 17) {
                    break;
                }
            }

            if (currentMonsters + spawnedTotal >= spawnLimit) {
                break;
            }
        }

        return spawnedTotal;
    }

    private static Optional<MobSpawnSettings.SpawnerData> pickSpawnData(ServerLevel level, BlockPos pos) {
        Holder<Biome> biome = level.getBiome(pos);
        WeightedList<MobSpawnSettings.SpawnerData> mobs = level.getChunkSource().getGenerator()
                .getMobsAt(biome, level.structureManager(), MobCategory.MONSTER, pos);
        Optional<MobSpawnSettings.SpawnerData> result = mobs.getRandom(RANDOM);
        if (result.isPresent() && !BloodmoonConfig.canSpawn(result.get().type())) {
            return Optional.empty();
        }
        return result;
    }
}
