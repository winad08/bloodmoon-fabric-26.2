package lumien.bloodmoon.server;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.Identifier;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

/**
 * Persistent bloodmoon state, ported from the original BloodmoonHandler
 * (WorldSavedData with NBT). Minecraft 26.2 SavedData uses Codec
 * serialization via a SavedDataType record.
 */
public class BloodmoonState extends SavedData {
    public static final Identifier FILE_ID = Identifier.fromNamespaceAndPath("bloodmoon", "bloodmoon");

    public static final Codec<BloodmoonState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.fieldOf("bloodMoon").forGetter(state -> state.bloodMoon),
            Codec.BOOL.fieldOf("forceBloodMoon").forGetter(state -> state.forceBloodMoon),
            Codec.INT.fieldOf("nightCounter").forGetter(state -> state.nightCounter),
            Codec.LONG.optionalFieldOf("lastHandledDay", -1L).forGetter(state -> state.lastHandledDay)
    ).apply(instance, BloodmoonState::new));

    public static final SavedDataType<BloodmoonState> TYPE = new SavedDataType<>(FILE_ID, BloodmoonState::new, CODEC, DataFixTypes.SAVED_DATA_MAP_DATA);

    public boolean bloodMoon;
    public boolean forceBloodMoon;
    public int nightCounter;
    /** The game day whose night has already been rolled for (-1 = none yet). */
    public long lastHandledDay;

    public BloodmoonState() {
        this(false, false, 0, -1L);
    }

    public BloodmoonState(boolean bloodMoon, boolean forceBloodMoon, int nightCounter) {
        this(bloodMoon, forceBloodMoon, nightCounter, -1L);
    }

    public BloodmoonState(boolean bloodMoon, boolean forceBloodMoon, int nightCounter, long lastHandledDay) {
        this.bloodMoon = bloodMoon;
        this.forceBloodMoon = forceBloodMoon;
        this.nightCounter = nightCounter;
        this.lastHandledDay = lastHandledDay;
    }
}
