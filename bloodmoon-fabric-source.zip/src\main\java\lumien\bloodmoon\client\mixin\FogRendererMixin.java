package lumien.bloodmoon.client.mixin;

import lumien.bloodmoon.client.ClientBloodmoonHandler;
import net.minecraft.client.renderer.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Black fog during a blood moon. The original mod cancelled the vanilla
 * fog color event and replaced it with darkened colors; here the RGB
 * arguments of the final Vector4f.set in computeFogColor are darkened
 * following the night sine curve (fogRemove).
 */
@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {
    @ModifyArgs(
            method = "computeFogColor",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/joml/Vector4f;set(FFFF)Lorg/joml/Vector4f;"
            )
    )
    private void bloodmoonBlackFog(Args args) {
        if (ClientBloodmoonHandler.blackFogEnabled()) {
            float factor = Math.max(0.0F, 1.0F - ClientBloodmoonHandler.fogRemove());
            args.set(0, ((float) args.get(0)) * factor);
            args.set(1, ((float) args.get(1)) * factor);
            args.set(2, ((float) args.get(2)) * factor);
        }
    }
}
