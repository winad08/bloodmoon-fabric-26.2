package lumien.bloodmoon;

import lumien.bloodmoon.config.BloodmoonConfig;
import lumien.bloodmoon.network.BloodmoonNetworking;
import lumien.bloodmoon.server.BloodmoonCommands;
import lumien.bloodmoon.server.BloodmoonHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Bloodmoon implements ModInitializer {
    public static final String MOD_ID = "bloodmoon";
    public static final Logger LOGGER = LoggerFactory.getLogger("Bloodmoon");

    @Override
    public void onInitialize() {
        BloodmoonConfig.load();
        BloodmoonNetworking.initialize();

        // World tick: bloodmoon trigger, spawner and dawn handling
        ServerTickEvents.END_LEVEL_TICK.register(BloodmoonHandler::endLevelTick);

        // Sync bloodmoon status to players joining the server
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                BloodmoonHandler.syncTo(handler.player));

        // Block sleeping during a bloodmoon (NO_SLEEP option)
        EntitySleepEvents.ALLOW_SLEEPING.register((Player player, net.minecraft.core.BlockPos sleepingPos) -> {
            if (BloodmoonConfig.GENERAL.NO_SLEEP
                    && player.level() instanceof net.minecraft.server.level.ServerLevel serverLevel
                    && BloodmoonHandler.isBloodmoonActive(serverLevel)) {
                return Player.BedSleepingProblem.OTHER_PROBLEM;
            }
            return null;
        });

        // /bloodmoon command
        CommandRegistrationCallback.EVENT.register(BloodmoonCommands::register);

        // Debug hook (off by default): start with -Dbloodmoon.autostart=true to
        // force a blood moon as soon as a world is loaded.
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            if (Boolean.getBoolean("bloodmoon.autostart")
                    || "true".equalsIgnoreCase(System.getenv("BLOODMOON_AUTOSTART"))) {
                LOGGER.info("[Bloodmoon] autostart enabled - forcing a blood moon");
                net.minecraft.server.level.ServerLevel overworld = server.overworld();
                server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), "time set 18000");
                BloodmoonHandler.start(overworld);
            }
        });

        LOGGER.info("[Bloodmoon] Bloodmoon Fabric port initialized");
    }
}
