# Bloodmoon — Fabric Port

移植自 [lumien231/Bloodmoon](https://github.com/lumien231/Bloodmoon)（原版为 Minecraft 1.12.2 + Forge + ASM coremod），
重写为 **Minecraft 26.2 + Fabric Loader** 模组，仅保留血月核心玩法（触发、血月期刷怪、红月视觉），
去掉了原版的自定义怪物与武器。

## 效果

血月降临时的夜晚：

- 月亮泛红、天空偏红、环境光转红、雾色变暗
- 怪物生成上限提升到原来的数倍，并且可以刷在离玩家很近的地方
- 默认 `CHANCE = 0.05`（5% 概率），可配置成每晚必出

## 安装

| 依赖 | 版本 |
| --- | --- |
| Minecraft | 26.2 |
| Fabric Loader | ≥ 0.19.5 |
| Fabric API | 0.161.0+26.2 |
| Java | 25 |

把构建产物 JAR（或 Release 里的 JAR）放进游戏目录的 `mods/` 文件夹即可。

## 配置

两种方式，**优先级**：游戏目录配置 **>** JAR 内配置。

1. **直接改 JAR 里的默认配置**：右键 JAR → 7-Zip/WinRAR 打开 → `config/bloodmoon.json` → 改完保存并重启游戏。
2. **标准外部配置**：游戏目录下的 `config/bloodmoon.json`（官方启动器通常是 `%appdata%\.minecraft\config\`）。
   游戏内执行 `/bloodmoon config` 会把当前生效的配置导出到该路径并打印完整位置。

```json
{
  "general":    { "NO_SLEEP": true, "VANISH": false, "RESPECT_GAMERULE": true, "SEND_MESSAGE": true },
  "appearance": { "RED_MOON": true, "RED_SKY": true, "RED_LIGHT": true, "BLACK_FOG": true },
  "schedule":   { "CHANCE": 0.05, "FULLMOON": false, "NTH_NIGHT": 0 },
  "spawning":   { "SPAWN_SPEED": 4, "SPAWN_LIMIT_MULT": 4, "SPAWN_RANGE": 2,
                  "SPAWN_DISTANCE": 24, "SPAWN_WHITELIST": [], "SPAWN_BLACKLIST": [] }
}
```

| 字段 | 说明 |
| --- | --- |
| `CHANCE` | 每晚触发概率，`1` = 每晚必出 |
| `NTH_NIGHT` | 每 n 夜必定一次（`0` 关闭） |
| `FULLMOON` | 满月必出 |
| `SPAWN_SPEED` | 每秒判断刷怪的频率倍率 |
| `SPAWN_LIMIT_MULT` | 怪物数量上限倍数 |
| `SPAWN_RANGE` | 距玩家多近可以刷（越小越贴脸，原版 24） |
| `SPAWN_WHITELIST` / `SPAWN_BLACKLIST` | 实体名单，白名单非空时只刷名单内，如 `["zombie","skeleton"]` |
| `RESPECT_GAMERULE` | 为 `true` 时遵守 `doMobSpawning` 规则；和平难度下永远不刷怪 |
| `NO_SLEEP` / `VANISH` / `SEND_MESSAGE` | 血月期间禁止睡觉 / 黎明时清除血月怪物 / 全服提示 |

改完配置需要**重启游戏**生效。

## 命令

需要 GM 及以上权限（`/bloodmoon`）：

| 命令 | 作用 |
| --- | --- |
| `/bloodmoon start` | 立刻开启血月（白天会自动跳到午夜） |
| `/bloodmoon force` | 下一个夜晚必定血月；夜晚执行则立即生效 |
| `/bloodmoon stop` | 结束当前血月 |
| `/bloodmoon status` | 输出当前状态：是否激活、游戏时间、难度、`doMobSpawning`、配置值 |
| `/bloodmoon config` | 导出当前生效配置到游戏目录并打印路径 |
| `/bloodmoon entitynames` | 列出可用于黑白名单的实体名 |

## 构建

```bash
# 需要 JDK 25
./gradlew build          # Windows 用 gradlew.bat build
```

产物在 `build/libs/bloodmoon-fabric-<version>.jar`。

调试模式（可选）：加 `-Dbloodmoon.autostart=true` 或环境变量 `BLOODMOON_AUTOSTART=true`，
世界加载完成后会自动强制一次血月，方便验证效果。

> 如果 `services.gradle.org` 下载不动，把 `gradle/wrapper/gradle-wrapper.properties` 里的
> `distributionUrl` 换成国内镜像即可（如 `https://mirrors.cloud.tencent.com/gradle/gradle-9.7.1-bin.zip`）。

## 项目结构

```
src/main/java/lumien/bloodmoon/
├── Bloodmoon.java                 主入口，注册事件与命令
├── client/
│   ├── BloodmoonClient.java       客户端入口
│   ├── ClientBloodmoonHandler.java 视觉强度曲线（按夜晚进度算正弦值）
│   └── mixin/                     红月/红天/红光/黑雾四个渲染注入
├── config/BloodmoonConfig.java    JSON 配置加载（JAR 内置 + 外部覆盖）
├── network/BloodmoonNetworking.java 服务端 -> 客户端状态同步
└── server/
    ├── BloodmoonHandler.java      世界 tick 驱动的状态机与夜晚判定
    ├── BloodmoonSpawner.java      血月期间的自定义刷怪逻辑
    ├── BloodmoonState.java        SavedData 持久化（Codec）
    └── BloodmoonCommands.java     /bloodmoon 命令
```

`PORTING_REPORT.md` 记录了完整的移植对照、26.2 的新 API 差异与踩坑过程。

## 已知限制

- 视觉效果依赖服务端向客户端同步的状态包，血月期间每 5 秒补发一次，切换维度返回主世界后会恢复
- `RESPECT_GAMERULE` 为 `true` 时，`doMobSpawning false` 或和平难度下不刷怪（红月视觉仍在）
- 刷怪以玩家周围 8 个 chunk 为范围，与 vanilla 一致，无人区域不会凭空刷怪

## 致谢与许可

- 原作者：**lumien** — [lumien231/Bloodmoon](https://github.com/lumien231/Bloodmoon)（Minecraft 1.12.2 / Forge）
- 本项目在 **MIT** 许可下发布，详见 [LICENSE](LICENSE)
