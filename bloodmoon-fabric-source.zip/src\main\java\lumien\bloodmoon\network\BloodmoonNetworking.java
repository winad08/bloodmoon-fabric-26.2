package lumien.bloodmoon.network;

import lumien.bloodmoon.Bloodmoon;
import lumien.bloodmoon.client.ClientBloodmoonHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * Port of the original PacketHandler + MessageBloodmoonStatus.
 * A single boolean payload telling clients whether a blood moon is active.
 */
public final class BloodmoonNetworking {
    public record BloodmoonStatusPayload(boolean bloodmoonActive) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<BloodmoonStatusPayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath("bloodmoon", "status"));

        public static final StreamCodec<RegistryFriendlyByteBuf, BloodmoonStatusPayload> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.BOOL, BloodmoonStatusPayload::bloodmoonActive,
                        BloodmoonStatusPayload::new);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    private BloodmoonNetworking() {
    }

    public static void initialize() {
        PayloadTypeRegistry.clientboundPlay().register(BloodmoonStatusPayload.TYPE, BloodmoonStatusPayload.CODEC);
    }

    @Environment(EnvType.CLIENT)
    public static void initializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(BloodmoonStatusPayload.TYPE, (payload, context) ->
                context.client().execute(() ->
                        ClientBloodmoonHandler.setBloodmoonActive(payload.bloodmoonActive())));
    }

    /** Sync the bloodmoon status to all players in the given level. */
    public static void sendToLevel(ServerLevel level, boolean active) {
        BloodmoonStatusPayload payload = new BloodmoonStatusPayload(active);
        for (ServerPlayer player : PlayerLookup.level(level)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    /** Sync the bloodmoon status to a single player (e.g. on join). */
    public static void sendTo(ServerPlayer player, boolean active) {
        ServerPlayNetworking.send(player, new BloodmoonStatusPayload(active));
    }
}
