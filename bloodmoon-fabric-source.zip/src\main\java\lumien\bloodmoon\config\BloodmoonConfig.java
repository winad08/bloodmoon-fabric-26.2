package lumien.bloodmoon.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lumien.bloodmoon.Bloodmoon;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Port of the original Forge @Config-based BloodmoonConfig.
 * Uses a simple JSON file (config/bloodmoon.json) since Fabric has no
 * annotation-based config system.
 */
public class BloodmoonConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("bloodmoon.json");
    /** Default config shipped inside the jar. */
    private static final String BUNDLED_PATH = "/config/bloodmoon.json";

    public static General GENERAL = new General();
    public static Appearance APPEARANCE = new Appearance();
    public static Schedule SCHEDULE = new Schedule();
    public static Spawning SPAWNING = new Spawning();

    public static class General {
        /** Whether players are not able to sleep on a bloodmoon */
        public boolean NO_SLEEP = true;
        /** Whether monsters spawned by a bloodmoon should die at dawn */
        public boolean VANISH = false;
        /** Whether bloodmoons should respect the doMobSpawning gamerule */
        public boolean RESPECT_GAMERULE = true;
        /** Whether all players in the overworld should receive a message when the bloodmoon starts */
        public boolean SEND_MESSAGE = true;
    }

    public static class Appearance {
        public boolean RED_MOON = true;
        public boolean RED_SKY = true;
        public boolean RED_LIGHT = true;
        public boolean BLACK_FOG = true;
    }

    public static class Schedule {
        /** The chance of a bloodmoon occurring at the beginning of a night (0=Never; 1=Every night; 0.05=5% of all nights) */
        public double CHANCE = 0.05;
        /** Whether there should be a bloodmoon whenever there is a full moon */
        public boolean FULLMOON = false;
        /** Every nth night there will be a bloodmoon (0 disables this, 1 would be every night, 2 every second night) */
        public int NTH_NIGHT = 0;
    }

    public static class Spawning {
        /** How much faster enemies spawn on a bloodmoon (0=Vanilla) */
        public int SPAWN_SPEED = 4;
        /** With which number should the default entity limit be multiplied on a blood moon */
        public int SPAWN_LIMIT_MULT = 4;
        /** How close can enemies spawn next to the player on a bloodmoon in blocks? (Vanilla=24) */
        public int SPAWN_RANGE = 2;
        /** How close can enemies spawn next to the world spawn (Vanilla=24) */
        public int SPAWN_DISTANCE = 24;
        /** If this isn't empty only monsters whose names are in this list will get spawned by the bloodmoon. (Example: ["skeleton","spider"]) */
        public String[] SPAWN_WHITELIST = new String[0];
        /** Monsters which are on this list won't get spawned by the bloodmoon (Has no effect when a whitelist is active). (Example: ["skeleton","spider"]) */
        public String[] SPAWN_BLACKLIST = new String[0];
    }

    // Cache entity type -> spawnable decision
    private static final Map<Identifier, Boolean> SPAWN_DECISION_CACHE = new HashMap<>();

    /**
     * Instance holder used for Gson (de)serialization. Gson does not
     * serialize static fields, so the static config holders are exposed
     * through non-static instance fields here.
     */
    private static class ConfigData {
        General general = GENERAL;
        Appearance appearance = APPEARANCE;
        Schedule schedule = SCHEDULE;
        Spawning spawning = SPAWNING;
    }

    public static void load() {
        boolean loaded = false;

        // 1) Config bundled inside the jar. Right-click the jar -> open with
        //    7-Zip/WinRAR -> config/bloodmoon.json to edit it.
        try (InputStream bundled = BloodmoonConfig.class.getResourceAsStream(BUNDLED_PATH)) {
            if (bundled != null) {
                ConfigData data = GSON.fromJson(new InputStreamReader(bundled, StandardCharsets.UTF_8), ConfigData.class);
                boolean hadContent = apply(data);
                if (hadContent) {
                    loaded = true;
                    Bloodmoon.LOGGER.info("[Bloodmoon] Loaded config bundled in the jar ({})", BUNDLED_PATH);
                }
            }
        } catch (Exception e) {
            Bloodmoon.LOGGER.warn("[Bloodmoon] Could not read the bundled config", e);
        }

        // 2) An external file in the game directory overrides the bundled one.
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = Files.readString(CONFIG_PATH, StandardCharsets.UTF_8);
                ConfigData read = GSON.fromJson(json, ConfigData.class);
                if (apply(read)) {
                    loaded = true;
                    Bloodmoon.LOGGER.info("[Bloodmoon] Bundled config overridden by {}", CONFIG_PATH);
                } else {
                    Bloodmoon.LOGGER.warn("[Bloodmoon] {} is empty or invalid - falling back to the bundled/default config", CONFIG_PATH);
                }
            }
        } catch (IOException e) {
            Bloodmoon.LOGGER.error("[Bloodmoon] Failed to load config", e);
        }

        // 3) Nothing usable found (no bundled file at all): write the defaults out.
        if (!loaded) {
            try {
                Files.createDirectories(CONFIG_PATH.getParent());
                Files.writeString(CONFIG_PATH, GSON.toJson(new ConfigData()), StandardCharsets.UTF_8);
                Bloodmoon.LOGGER.info("[Bloodmoon] Created default config at {}", CONFIG_PATH);
            } catch (IOException e) {
                Bloodmoon.LOGGER.error("[Bloodmoon] Failed to write the default config", e);
            }
        }

        SPAWN_DECISION_CACHE.clear();
    }

    /**
     * Copies all non-null sections of the given data over the active config.
     * Returns whether at least one section was present.
     */
    private static boolean apply(ConfigData data) {
        if (data == null) {
            return false;
        }
        boolean any = false;
        if (data.general != null) {
            GENERAL = data.general;
            any = true;
        }
        if (data.appearance != null) {
            APPEARANCE = data.appearance;
            any = true;
        }
        if (data.schedule != null) {
            SCHEDULE = data.schedule;
            any = true;
        }
        if (data.spawning != null) {
            SPAWNING = data.spawning;
            any = true;
        }
        return any;
    }

    /** Writes the currently active config into the external config file. */
    public static Path export() throws IOException {
        Files.createDirectories(CONFIG_PATH.getParent());
        Files.writeString(CONFIG_PATH, GSON.toJson(new ConfigData()), StandardCharsets.UTF_8);
        return CONFIG_PATH;
    }

    public static Path configPath() {
        return CONFIG_PATH;
    }

    /**
     * Decides whether the given entity type may be spawned by the bloodmoon
     * spawner, honoring the whitelist/blacklist. Names are matched against the
     * entity id path (e.g. "skeleton" for "minecraft:skeleton"), case-insensitive.
     */
    public static boolean canSpawn(EntityType<?> entityType) {
        Identifier key = BuiltInRegistries.ENTITY_TYPE.getKey(entityType);
        return SPAWN_DECISION_CACHE.computeIfAbsent(key, k -> {
            String name = k.getPath().toLowerCase(Locale.ROOT);
            if (SPAWNING.SPAWN_WHITELIST.length > 0) {
                for (String entry : SPAWNING.SPAWN_WHITELIST) {
                    if (entry.toLowerCase(Locale.ROOT).equals(name)) {
                        return true;
                    }
                }
                return false;
            }
            if (SPAWNING.SPAWN_BLACKLIST.length > 0) {
                for (String entry : SPAWNING.SPAWN_BLACKLIST) {
                    if (entry.toLowerCase(Locale.ROOT).equals(name)) {
                        return false;
                    }
                }
            }
            return true;
        });
    }
}
