package lumien.bloodmoon.client;

import lumien.bloodmoon.network.BloodmoonNetworking;
import net.fabricmc.api.ClientModInitializer;

public class BloodmoonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BloodmoonNetworking.initializeClient();
        ClientBloodmoonHandler.initialize();
    }
}
