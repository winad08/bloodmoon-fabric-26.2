# Bloodmoon Forge → Fabric 移植报告

## 概述

原版 Bloodmoon mod（Minecraft 1.12.2 Forge + ASM coremod）已成功移植到 **Minecraft 26.2 + Fabric**。

- **产物**: `build/libs/bloodmoon-fabric-2.0.0.jar`（34 KB，BUILD SUCCESSFUL）
- **运行验证**: `gradlew runClient` 已启动 Minecraft 26.2 客户端，mod 正常加载，无崩溃、无 Mixin 注入失败
- **移植范围**: 仅保留血月核心机制（触发、状态、怪物生成、视觉效果），移除了自定义怪物/武器等非血月功能（原模组该部分本就未包含在此源码中）

## 环境与工具链

| 组件 | 版本 |
|---|---|
| Minecraft | 26.2 |
| Fabric Loader | 0.19.5 |
| Fabric Loom | 1.18.2 |
| Fabric API | 0.161.0+26.2 |
| Mixin | 0.17.4+mixin.0.8.7 (sponge-mixin) |
| Gradle | 9.7.1 |
| Java | 25 (Temurin 25.0.4.1) |
| Mappings | Mojang official（26.x 已停止 Yarn） |

## 架构对照

| 原 Forge/ASM 实现 | Fabric 26.2 实现 |
|---|---|
| ASM coremod（ClassTransformer 运行时字节码注入） | 3 个客户端 Mixin（无需 coremod） |
| Forge 事件总线（WorldTickEvent 等） | `ServerTickEvents.END_LEVEL_TICK` 等 Fabric API 事件 |
| `@Config` 注解配置 | JSON 配置文件（`config/bloodmoon.json`） |
| SimpleNetworkWrapper + IMessage | `PayloadTypeRegistry` + `ServerPlayNetworking`（自定义 Payload） |
| NBT 读写 SavedData | Codec 序列化的 `SavedDataType<BloodmoonState>` |
| `world.random` | 自建 `RandomSource.create()`（26.2 中 Level.random 为 protected） |
| GL11.glColor3f 固定管线 | `DynamicUniforms.writeTransform` 颜色调制器（`@ModifyArg`） |
| 自写 lightmap 像素操作 | `LightmapRenderState.skyLightColor/ambientColor`（GPU shader 参数） |

## 服务端组件

### lumien.bloodmoon.Bloodmoon（ModInitializer）
注册所有事件：
- `ServerTickEvents.END_LEVEL_TICK` → 血月状态机
- `ServerPlayConnectionEvents.JOIN` → 玩家加入时同步血月状态
- `EntitySleepEvents.ALLOW_SLEEPING` → NO_SLEEP 配置下返回 `BedSleepingProblem.OTHER_PROBLEM`
- `CommandRegistrationCallback.EVENT` → `/bloodmoon` 命令

### BloodmoonHandler（世界 tick 状态机）
- 血月在世界时间 `12000`（日落）时按概率触发；`time < 12000` 时判定黎明并结束
- 触发条件支持：随机概率（默认 5%）、仅满月（`getMoonBrightness >= 1.0F`）、每 N 晚
- 支持 `forceBloodMoon` 强制模式（`/bloodmoon force`）
- VANISH 开启时黎明移除所有血月生成的怪物（通过实体 tag 标记）

### BloodmoonState（持久化，SavedData + Codec）
- 字段：`bloodMoon`、`forceBloodMoon`、`nightCounter`
- 使用 26.2 新 API：`new SavedDataType<>(id, factory, CODEC, DataFixTypes.SAVED_DATA_MAP_DATA)`

### BloodmoonSpawner（血月怪物生成器）
- 移植原版 `findChunksForSpawning`：玩家周围 8 chunk 半径内生成
- 怪物上限 = 原版上限（MONSTER 类别 70/chunk）× `SPAWN_LIMIT_MULT`（默认 4）
- 生成速度 ×`SPAWN_SPEED`（默认 4）
- 白名单/黑名单过滤（`BloodmoonConfig.canSpawn`，按实体 ID path 匹配并缓存）
- 生成的怪物通过 `entity.addTag("bloodmoon_spawned")` 标记，供黎明 VANISH 移除

### BloodmoonCommands
- `/bloodmoon force` — 强制下一晚血月（权限：`Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)`，26.2 新权限 API）
- `/bloodmoon stop` — 停止当前血月
- `/bloodmoon entitynames` — 列出所有实体 ID（供白名单/黑名单配置）

## 客户端组件

### 网络同步（BloodmoonNetworking）
- `BloodmoonStatusPayload(boolean bloodmoonActive)` 自定义 `CustomPacketPayload`
- 服务端通过 `PlayerLookup.level(level)` + `ServerPlayNetworking.send()` 广播
- 客户端注册 `ClientPlayNetworking.registerGlobalReceiver` 更新本地状态

### ClientBloodmoonHandler
- 维护血月视觉强度正弦曲线（夜晚进度 0→1→0），派生：
  - `nightSin()` 基础曲线
  - `lightSub()` 红光强度
  - `skyColorAdd()` 天空红色增量
  - `moonColorRed()` 月亮红度
  - `fogRemove()` 雾气黑度

### Mixin（3 个，均最小化注入）

**SkyRendererMixin**（红月 + 红天）
- 红月：`@ModifyArg` 修改 `renderMoon` 中 `DynamicUniforms.writeTransform(Matrix4f, Vector4f)` 的 index=1 颜色调制器
- 红天：`@Inject`（FIELD PUTFIELD + Shift.BY 1）在 `extractRenderState` 中给 `SkyRenderState.skyColor` 红通道加值

**LightmapRenderStateExtractorMixin**（红光）
- 两处 `@Inject`（FIELD PUTFIELD + Shift.BY 1）在 `extract` 后削减 `skyLightColor` / `ambientColor` 的绿/蓝通道（对应原 mod 的 lightmap 像素操作）

**FogRendererMixin**（黑雾）
- `@ModifyArgs` 修改 `computeFogColor` 中 `Vector4f.set(FFFF)` 调用，RGB 通道按 `1 - fogRemove` 缩放

## 配置（config/bloodmoon.json）

| 分类 | 选项 | 默认值 |
|---|---|---|
| General | NO_SLEEP | true |
| General | VANISH | true |
| General | RESPECT_GAMERULE | true |
| General | SEND_MESSAGE | true |
| Appearance | RED_MOON / RED_SKY / RED_LIGHT / BLACK_FOG | 全 true |
| Schedule | CHANCE | 0.05 |
| Schedule | FULLMOON / NTH_NIGHT | false |
| Spawning | SPAWN_SPEED / SPAWN_LIMIT_MULT | 4 / 4 |
| Spawning | SPAWN_RANGE / SPAWN_DISTANCE | 2 / 24 |
| Spawning | WHITELIST / BLACKLIST | 空 |

## 移植过程中的关键坑与解法

1. **Yarn mappings 已停止支持 26.x** → 使用 Mojang official mappings
2. **`Level.random` 为 protected** → 自建 `RandomSource.create()`
3. **`ChunkPos` 变为 record** → 用 `x()` / `z()` 访问器替代字段访问
4. **SavedData 改用 Codec** → `SavedDataType<T>` record + `StreamCodec`
5. **26.2 新权限系统** → `Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)` 替代 `source.hasPermission(2)`
6. **Mixin `@At` 无 `maxShiftBy` 参数**（sponge-mixin 0.17.4 实测，javap 验证）→ 移除该参数；`Shift.BY=1` 超限只是良性运行时警告，注入仍正常应用
7. **`EntityTypeTest.forClass` 泛型推断失败** → 显式类型见证 `EntityTypeTest.<Entity, Mob>forClass(Mob.class)`
8. **渲染管线全面 GPU 化** → 固定管线的 `GL11.glColor3f` 钩子改为 `DynamicUniforms.writeTransform` 颜色调制器注入；lightmap 像素操作改为 shader 输入参数（`LightmapRenderState`）注入

## 验证结果

- ✅ `gradlew clean build` BUILD SUCCESSFUL（Java 25 编译，0 错误）
- ✅ `gradlew runClient` 启动 Minecraft 26.2 客户端，mod 加载成功
- ✅ Mixin 全部注入成功（仅 `Shift.BY` 超限的良性警告，不影响功能）
- ✅ 产物 `bloodmoon-fabric-2.0.0.jar` 可直接放入 Fabric 26.2 的 `mods/` 目录

## 使用方法

1. 安装 Fabric Loader 0.19.5+ 和 Fabric API 0.161.0+26.2
2. 将 `bloodmoon-fabric-2.0.0.jar` 放入 `mods/` 文件夹
3. 首次启动后编辑 `config/bloodmoon.json` 调整配置
4. 游戏内命令：
   - `/bloodmoon start` — 立刻开启血月（若处于白天会自动跳到午夜）
   - `/bloodmoon force` — 下一个夜晚必定血月（夜晚中执行则立刻开始）
   - `/bloodmoon stop` — 结束当前血月
   - `/bloodmoon status` — 输出当前状态（是否激活、时间、难度、doMobSpawning、配置值）
   - `/bloodmoon entitynames` — 列出可用于黑白名单的实体名

## 实测排查记录（"能进游戏但没效果"）

1. **红光/红天完全不可见**：Mixin 日志显示
   `@Inject(@At("FIELD")) Shift.BY=1 ... exceeds the maximum allowed value: 0`。
   sponge-mixin 0.8.7 把位移 clamp 成 0，等于**在 PUTFIELD 之前**执行回调，
   随后原版赋值把我们改的值覆盖掉。修复：改用 `@At("RETURN")` 在方法返回前统一改一次
   （`LightmapRenderStateExtractor.extract`、`SkyRenderer.extractRenderState`）。
   修复后客户端日志中该类警告为 0 条。
2. **血月几乎不触发**：原逻辑要求 `time == 12000` 严格相等，迟到一 tick（关掉 daylight
   cycle、`/time set`、掉帧）就永久错过。修复：改为"每个游戏日掷骰一次"
   （`lastHandledDay` 写入 SavedData）+ 黄昏窗口（入夜 1000 tick 内），
   深夜载入存档不会立刻触发一个几秒就结束的血月。
3. **看不到效果无法自查**：新增 `/bloodmoon start`（立即）与 `/bloodmoon status`，
   并在血月开始/结束、刷怪数量处打 INFO 日志；血月期间每 5 秒向客户端重发一次状态包。
4. **维度切换丢失状态**：客户端进入下界/末地会把 `bloodmoonActive` 清成 false 且不恢复，
   修复为只把视觉强度归零、保留标志位。

实机验证（dev 环境真实存档）：血月正常开始/结束，一个夜晚内血月刷怪 393 / 622 只，
Mixin 注入无失败、无异常堆栈。

调试开关：`-Dbloodmoon.autostart=true`（或环境变量 `BLOODMOON_AUTOSTART=true`）
可在世界加载完成后自动强制一次血月，默认关闭。

## 配置也可以直接改 JAR 里的文件

JAR 根目录内置了 `config/bloodmoon.json`，右键 JAR → 用 7-Zip/WinRAR 打开 → 编辑 `config/bloodmoon.json` → 保存即可生效（记得重启游戏）。

加载优先级：

1. JAR 内 `config/bloodmoon.json`（随 JAR 分发，可直接在压缩包里改）
2. 游戏目录 `config/bloodmoon.json`（**若存在则覆盖 JAR 内的**，这是 Fabric/Forge 的标准方式）
3. 代码内默认值

只有当两者都不存在时，mod 才会在游戏目录自动生成一份配置。
`/bloodmoon config` 可把当前生效的配置导出到游戏目录（并打印绝对路径）。
