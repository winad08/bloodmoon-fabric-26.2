package lumien.bloodmoon.client;

import lumien.bloodmoon.config.BloodmoonConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

/**
 * Port of the original ClientBloodmoonHandler. Tracks the client-side
 * bloodmoon state (synced from the server) and computes the intensity
 * curve for the visual effects using a sine over the night time.
 */
@Environment(EnvType.CLIENT)
public final class ClientBloodmoonHandler {
    private static final float SIN_MAX = (float) (Math.PI / 12000.0);

    private static boolean bloodmoonActive = false;

    // Visual intensities, recomputed every client tick
    private static float sin;
    private static float lightSub;
    private static float skyColorAdd;
    private static float moonColorRed;
    private static float fogRemove;

    private ClientBloodmoonHandler() {
    }

    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(Minecraft.getInstance()));
    }

    public static void setBloodmoonActive(boolean active) {
        bloodmoonActive = active;
    }

    public static boolean isBloodmoonActive() {
        return bloodmoonActive;
    }

    /** Sine of night progress, 0 at dusk/dawn, 1 in the middle of the night. */
    public static float nightSin() {
        return sin;
    }

    public static float lightSub() {
        return lightSub;
    }

    public static float skyColorAdd() {
        return skyColorAdd;
    }

    public static float moonColorRed() {
        return moonColorRed;
    }

    public static float fogRemove() {
        return fogRemove;
    }

    public static boolean redMoonEnabled() {
        return isBloodmoonActive() && BloodmoonConfig.APPEARANCE.RED_MOON;
    }

    public static boolean redSkyEnabled() {
        return isBloodmoonActive() && BloodmoonConfig.APPEARANCE.RED_SKY;
    }

    public static boolean redLightEnabled() {
        return isBloodmoonActive() && BloodmoonConfig.APPEARANCE.RED_LIGHT;
    }

    public static boolean blackFogEnabled() {
        return isBloodmoonActive() && BloodmoonConfig.APPEARANCE.BLACK_FOG;
    }

    private static void tick(Minecraft client) {
        if (!bloodmoonActive) {
            resetIntensity();
            return;
        }

        // Outside the overworld (or without a level) the effects are simply
        // disabled for the moment - the flag itself is kept so the visuals
        // come back when the player returns.
        if (client.level == null || client.player == null || client.level.dimension() != Level.OVERWORLD) {
            resetIntensity();
            return;
        }

        float difTime = (client.level.getOverworldClockTime() % 24000) - 12000;
        sin = Math.max(0.0F, (float) Math.sin(difTime * SIN_MAX));
        lightSub = sin * 150.0F;
        skyColorAdd = sin * 0.2F;
        moonColorRed = (float) Math.min(1.0, sin * 1.4);
        fogRemove = sin * 0.4F;
    }

    private static void resetIntensity() {
        sin = 0;
        lightSub = 0;
        skyColorAdd = 0;
        moonColorRed = 0;
        fogRemove = 0;
    }
}
