package lumien.bloodmoon.client.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import lumien.bloodmoon.client.ClientBloodmoonHandler;
import net.minecraft.client.renderer.SkyRenderer;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.joml.Vector4f;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Red moon + red sky during a blood moon.
 * - Red moon: modifies the color modulator passed to writeTransform in renderMoon
 *   (replacement for the original GL11.glColor3f(0.8, 0, 0) hook).
 * - Red sky: adds to the red channel of the extracted sky color
 *   (replacement for the original skyColorHook).
 */
@Mixin(SkyRenderer.class)
public abstract class SkyRendererMixin {
    /**
     * The moon quad is tinted via the DynamicUniforms color modulator.
     * Green/blue are reduced following the night sine curve (moonColorRed).
     */
    @ModifyArg(
            method = "renderMoon",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/DynamicUniforms;writeTransform(Lorg/joml/Matrix4f;Lorg/joml/Vector4f;)Lcom/mojang/blaze3d/buffers/GpuBufferSlice;"
            ),
            index = 1
    )
    private Vector4f bloodmoonRedMoon(Vector4f colorModulator) {
        if (ClientBloodmoonHandler.redMoonEnabled()) {
            float redAmount = ClientBloodmoonHandler.moonColorRed();
            float greenBlue = Math.max(0.0F, 1.0F - redAmount);
            return new Vector4f(1.0F, greenBlue, greenBlue, colorModulator.w());
        }
        return colorModulator;
    }

    /**
     * Shifts the sky color towards red right after vanilla extracts it.
     */
    @Inject(
            method = "extractRenderState",
            at = @At("RETURN")
    )
    private void bloodmoonRedSky(net.minecraft.client.multiplayer.ClientLevel level, float partialTicks,
                                 net.minecraft.client.Camera camera,
                                 net.minecraft.client.renderer.state.level.SkyRenderState state,
                                 CallbackInfo ci) {
        if (ClientBloodmoonHandler.redSkyEnabled()) {
            int color = state.skyColor;
            int red = ARGB.red(color);
            int green = ARGB.green(color);
            int blue = ARGB.blue(color);
            int add = (int) (ClientBloodmoonHandler.skyColorAdd() * 255.0F);
            red = Mth.clamp(red + add, 0, 255);
            state.skyColor = ARGB.color(ARGB.alpha(color), red, green, blue);
        }
    }
}
