package lumien.bloodmoon.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import lumien.bloodmoon.Bloodmoon;
import lumien.bloodmoon.config.BloodmoonConfig;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.gamerules.GameRules;

import java.util.stream.Collectors;

/**
 * Port of the original CommandBloodmoon:
 * /bloodmoon start       - starts a blood moon immediately (jumps to night if it is day)
 * /bloodmoon force       - guarantees a blood moon the next time night falls
 * /bloodmoon stop        - stops the current blood moon
 * /bloodmoon status      - prints the current state (useful for debugging)
 * /bloodmoon entitynames - lists all entity type names usable in the config lists
 */
public final class BloodmoonCommands {
    private BloodmoonCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext context, Commands.CommandSelection environment) {
        dispatcher.register(Commands.literal("bloodmoon")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(Commands.literal("start").executes(BloodmoonCommands::start))
                .then(Commands.literal("force").executes(BloodmoonCommands::force))
                .then(Commands.literal("stop").executes(BloodmoonCommands::stop))
                .then(Commands.literal("status").executes(BloodmoonCommands::status))
                .then(Commands.literal("config").executes(BloodmoonCommands::config))
                .then(Commands.literal("entitynames").executes(BloodmoonCommands::entityNames)));
    }

    private static int start(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        ServerLevel overworld = source.getServer().overworld();

        long time = Math.floorMod(overworld.getOverworldClockTime(), 24000L);
        if (time < 12000L) {
            // It is day - jump to midnight so the blood moon is visible right away.
            source.getServer().getCommands().performPrefixedCommand(source, "time set 18000");
        }

        BloodmoonHandler.start(overworld);
        source.sendSuccess(() -> Component.translatable("commands.bloodmoon.start.success"), true);
        Bloodmoon.LOGGER.info("[Bloodmoon] Blood moon started by {}", source.getTextName());
        return 1;
    }

    private static int force(CommandContext<CommandSourceStack> context) {
        ServerLevel overworld = context.getSource().getServer().overworld();
        BloodmoonHandler.force(overworld);
        if (Math.floorMod(overworld.getOverworldClockTime(), 24000L) >= 12000L) {
            // Already night: trigger immediately instead of waiting for dusk.
            BloodmoonHandler.start(overworld);
        }
        context.getSource().sendSuccess(() -> Component.translatable("commands.bloodmoon.force.success"), true);
        Bloodmoon.LOGGER.info("[Bloodmoon] Blood moon forced by {}", context.getSource().getTextName());
        return 1;
    }

    private static int stop(CommandContext<CommandSourceStack> context) {
        ServerLevel overworld = context.getSource().getServer().overworld();
        BloodmoonHandler.stop(overworld);
        context.getSource().sendSuccess(() -> Component.translatable("commands.bloodmoon.stop.success"), true);
        return 1;
    }

    private static int status(CommandContext<CommandSourceStack> context) {
        ServerLevel overworld = context.getSource().getServer().overworld();
        long clock = overworld.getOverworldClockTime();
        long time = Math.floorMod(clock, 24000L);
        boolean active = BloodmoonHandler.isBloodmoonActive(overworld);
        boolean scheduled = BloodmoonHandler.isBloodmoonScheduled(overworld);
        boolean mobsAllowed = overworld.getGameRules().get(GameRules.SPAWN_MOBS);
        String difficulty = String.valueOf(overworld.getDifficulty()).toLowerCase(java.util.Locale.ROOT);

        context.getSource().sendSuccess(() -> Component.literal("[Bloodmoon] active=" + active
                + ", scheduledNextNight=" + scheduled
                + ", time=" + time + (time >= 12000L ? " (night)" : " (day)")
                + ", difficulty=" + difficulty
                + ", doMobSpawning=" + mobsAllowed
                + ", chance=" + BloodmoonConfig.SCHEDULE.CHANCE
                + ", spawnSpeed=" + BloodmoonConfig.SPAWNING.SPAWN_SPEED), false);
        return 1;
    }

    private static int config(CommandContext<CommandSourceStack> context) {
        try {
            java.nio.file.Path path = BloodmoonConfig.export();
            String absolute = path.toAbsolutePath().toString();
            context.getSource().sendSuccess(() -> Component.literal("[Bloodmoon] Exported config to " + absolute), false);
        } catch (java.io.IOException e) {
            Bloodmoon.LOGGER.error("[Bloodmoon] Failed to export the config", e);
            context.getSource().sendFailure(Component.literal("[Bloodmoon] Failed to export the config"));
        }
        return 1;
    }

    private static int entityNames(CommandContext<CommandSourceStack> context) {
        String names = context.getSource().getLevel().registryAccess()
                .lookupOrThrow(Registries.ENTITY_TYPE)
                .listElements()
                .map(holder -> holder.unwrapKey().map(key -> {
                    Identifier id = key.identifier();
                    return id.getNamespace().equals("minecraft") ? id.getPath() : id.toString();
                }).orElse(""))
                .filter(name -> !name.isEmpty())
                .sorted()
                .collect(Collectors.joining(", "));
        context.getSource().sendSuccess(() -> Component.literal(names), false);
        return 1;
    }
}
