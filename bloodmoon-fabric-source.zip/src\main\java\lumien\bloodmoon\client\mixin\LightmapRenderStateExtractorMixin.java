package lumien.bloodmoon.client.mixin;

import lumien.bloodmoon.client.ClientBloodmoonHandler;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import net.minecraft.client.renderer.state.LightmapRenderState;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Red light during a blood moon. The original mod subtracted from the
 * green/blue channels of the lightmap texture depending on sky light
 * height; the 26.2 lightmap is a GPU shader driven by
 * LightmapRenderState.skyLightColor/ambientColor, so the green/blue
 * components of those colors are reduced following the night sine curve.
 */
@Mixin(LightmapRenderStateExtractor.class)
public abstract class LightmapRenderStateExtractorMixin {
    /**
     * Scales down green and blue of the sky light color right after it is
     * assigned. Runs only when the state is actually refreshed, so no
     * compounding across frames.
     */
    @Inject(
            method = "extract",
            at = @At("RETURN")
    )
    private void bloodmoonRedSkyLight(LightmapRenderState renderState, float partialTicks, CallbackInfo ci) {
        if (ClientBloodmoonHandler.redLightEnabled()) {
            Vector3fc color = renderState.skyLightColor;
            renderState.skyLightColor = bloodmoon$reduceGreenBlue(color);
        }
    }

    /** Same treatment for the ambient (moon light) color. */
    @Inject(
            method = "extract",
            at = @At("RETURN")
    )
    private void bloodmoonRedAmbient(LightmapRenderState renderState, float partialTicks, CallbackInfo ci) {
        if (ClientBloodmoonHandler.redLightEnabled()) {
            Vector3fc color = renderState.ambientColor;
            renderState.ambientColor = bloodmoon$reduceGreenBlue(color);
        }
    }

    private static Vector3f bloodmoon$reduceGreenBlue(Vector3fc color) {
        float sin = ClientBloodmoonHandler.nightSin();
        // Port of the original lightmap manipulation:
        // green -= mod * lightSub * (sin/2 + 1), blue -= mod * lightSub * 2.3
        float greenSub = sin * 0.45F;
        float blueSub = sin * 0.75F;
        return new Vector3f(
                color.x(),
                Math.max(0.0F, color.y() - greenSub),
                Math.max(0.0F, color.z() - blueSub));
    }
}
