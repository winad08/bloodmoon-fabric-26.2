package lumien.bloodmoon.server;

import lumien.bloodmoon.Bloodmoon;
import lumien.bloodmoon.config.BloodmoonConfig;
import lumien.bloodmoon.network.BloodmoonNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.storage.SavedDataStorage;

import java.util.List;

/**
 * Port of the original BloodmoonHandler world tick logic, driven by Fabric's
 * ServerTickEvents.END_LEVEL_TICK instead of the Forge event bus.
 *
 * Triggering is based on "one roll per game day" instead of the original
 * exact time match (time == 12000), which was easy to miss (e.g. when the
 * daylight cycle is disabled or time is skipped with /time set).
 */
public final class BloodmoonHandler {
    public static final String SPAWN_TAG = BloodmoonSpawner.SPAWN_TAG;

    /** How often (in ticks) the status is re-sent to clients while active. */
    private static final int RESYNC_INTERVAL = 100;

    /** Ticks after dusk in which the nightly roll still counts as "night fall". */
    private static final long DUSK_WINDOW = 1000L;

    private static final RandomSource RANDOM = RandomSource.create();

    /** Mobs spawned during the current blood moon (logging only). */
    private static int spawnedTotal = 0;

    private BloodmoonHandler() {
    }

    /** Called at the end of every server level tick. */
    public static void endLevelTick(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD) {
            return;
        }

        BloodmoonState state = getState(level);
        long clock = level.getOverworldClockTime();
        long day = Math.floorDiv(clock, 24000L);
        long time = Math.floorMod(clock, 24000L);
        boolean night = time >= 12000L;

        if (state.bloodMoon) {
            // Bloodmoon ends at dawn
            if (!night) {
                setBloodmoon(level, state, false);
                return;
            }

            boolean spawnAllowed = !BloodmoonConfig.GENERAL.RESPECT_GAMERULE
                    || level.getGameRules().get(GameRules.SPAWN_MOBS);
            if (spawnAllowed && level.getDifficulty() != Difficulty.PEACEFUL) {
                int spawned = 0;
                for (int i = 0; i < BloodmoonConfig.SPAWNING.SPAWN_SPEED; i++) {
                    spawned += BloodmoonSpawner.spawnCycle(level, true);
                }
                spawnedTotal += spawned;
                if (spawned > 0 && clock % 1200 == 0) {
                    Bloodmoon.LOGGER.info("[Bloodmoon] {} mobs spawned during this blood moon", spawnedTotal);
                }
            }

            // Re-sync periodically so a client that missed the packet still
            // shows the effects.
            if (time % RESYNC_INTERVAL == 0) {
                BloodmoonNetworking.sendToLevel(level, true);
            }
            return;
        }

        if (!night || state.lastHandledDay == day) {
            return;
        }

        // First tick of this night: roll for a blood moon exactly once.
        state.lastHandledDay = day;
        state.setDirty();

        // Loading a save late at night (or a skipped clock) should not start a
        // blood moon that ends a few ticks later - only dusk counts.
        if (time > 12000L + DUSK_WINDOW) {
            return;
        }

        if (BloodmoonConfig.SCHEDULE.NTH_NIGHT != 0) {
            state.nightCounter--;
            if (state.nightCounter < 0) {
                state.nightCounter = BloodmoonConfig.SCHEDULE.NTH_NIGHT;
            }
            state.setDirty();
        }

        boolean fullMoon = BloodmoonConfig.SCHEDULE.FULLMOON
                && level.getMoonBrightness(BlockPos.ZERO) >= 1.0F;
        boolean nthNight = BloodmoonConfig.SCHEDULE.NTH_NIGHT != 0 && state.nightCounter == 0;

        if (state.forceBloodMoon
                || RANDOM.nextDouble() < BloodmoonConfig.SCHEDULE.CHANCE
                || fullMoon
                || nthNight) {
            state.forceBloodMoon = false;
            setBloodmoon(level, state, true);

            if (BloodmoonConfig.GENERAL.SEND_MESSAGE) {
                Component message = Component.translatable("text.bloodmoon.notify").withStyle(ChatFormatting.RED);
                for (ServerPlayer player : level.players()) {
                    player.sendSystemMessage(message);
                }
            }

            if (state.nightCounter == 0 && BloodmoonConfig.SCHEDULE.NTH_NIGHT != 0) {
                state.nightCounter = BloodmoonConfig.SCHEDULE.NTH_NIGHT;
                state.setDirty();
            }
        }
    }

    private static void setBloodmoon(ServerLevel level, BloodmoonState state, boolean active) {
        if (state.bloodMoon != active) {
            state.bloodMoon = active;
            state.setDirty();
            if (active) {
                spawnedTotal = 0;
            }
            Bloodmoon.LOGGER.info("[Bloodmoon] Blood moon {} in {} (mobs spawned: {})",
                    active ? "started" : "ended", level.dimension().identifier(), spawnedTotal);
            BloodmoonNetworking.sendToLevel(level, active);

            if (!active && BloodmoonConfig.GENERAL.VANISH) {
                removeBloodmoonMobs(level);
            }
        }
    }

    /** Removes all mobs that were spawned by the bloodmoon (VANISH option). */
    private static void removeBloodmoonMobs(ServerLevel level) {
        List<? extends Mob> tagged = level.getEntities(EntityTypeTest.<Entity, Mob>forClass(Mob.class),
                mob -> mob.entityTags().contains(SPAWN_TAG));
        for (Mob mob : tagged) {
            mob.discard();
        }
        if (!tagged.isEmpty()) {
            Bloodmoon.LOGGER.info("[Bloodmoon] Removed {} bloodmoon mobs at dawn", tagged.size());
        }
    }

    private static BloodmoonState getState(ServerLevel level) {
        SavedDataStorage storage = level.getDataStorage();
        return storage.computeIfAbsent(BloodmoonState.TYPE);
    }

    /** Whether a blood moon is currently active in the given level's overworld state. */
    public static boolean isBloodmoonActive(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD) {
            return false;
        }
        BloodmoonState state = getState(level);
        return state.bloodMoon;
    }

    /** Starts a blood moon right now (used by /bloodmoon start). */
    public static void start(ServerLevel level) {
        BloodmoonState state = getState(level);
        state.forceBloodMoon = false;
        setBloodmoon(level, state, true);

        if (BloodmoonConfig.GENERAL.SEND_MESSAGE) {
            Component message = Component.translatable("text.bloodmoon.notify").withStyle(ChatFormatting.RED);
            for (ServerPlayer player : level.players()) {
                player.sendSystemMessage(message);
            }
        }
    }

    /** /bloodmoon force - a blood moon is guaranteed the next time night falls. */
    public static void force(ServerLevel level) {
        BloodmoonState state = getState(level);
        state.forceBloodMoon = true;
        // Re-roll the current night too if the command is used during it.
        state.lastHandledDay = -1L;
        state.setDirty();
    }

    /** /bloodmoon stop - ends the current blood moon. */
    public static void stop(ServerLevel level) {
        BloodmoonState state = getState(level);
        setBloodmoon(level, state, false);
    }

    /** Whether a blood moon is scheduled for the next night. */
    public static boolean isBloodmoonScheduled(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD) {
            return false;
        }
        return getState(level).forceBloodMoon;
    }

    /** Syncs the current status to a player joining the overworld. */
    public static void syncTo(ServerPlayer player) {
        if (player.level() instanceof ServerLevel serverLevel && serverLevel.dimension() == Level.OVERWORLD) {
            BloodmoonState state = getState(serverLevel);
            if (state.bloodMoon) {
                BloodmoonNetworking.sendTo(player, true);
            }
        }
    }
}
